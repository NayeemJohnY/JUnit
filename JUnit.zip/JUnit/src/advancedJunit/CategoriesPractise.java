package advancedJunit;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.endsWith;
import static org.hamcrest.CoreMatchers.startsWith;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThat;
import static org.junit.Assume.assumeTrue;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import assertions.AssertionsClass;

public class CategoriesPractise {
	
	
	@Test
	@Category(Smoke.class)
	public  void assumeCheck() {
		assumeTrue("True is not false", true);
		System.out.println("True is not false");
	
	}
	@Test
	@Category({ Regeression.class})
	public  void All() {
		String tested="Nayeem";
		
				
		assertThat("Matching failed", tested, allOf(startsWith("N"),endsWith("m"),containsString("e")));
		
	}
	@Test
	@Category(Smoke.class)
	public  void any() {
		String tested="Nayeem";
		
				
		assertThat("Matching failed", tested, anyOf(startsWith("N"),endsWith("m"),containsString("e")));
		
	}
	@Test
	@Category({ Regeression.class})
	public void A_StringEq()
	{
		String one="one";
		String one_1="one";
		 
		assertEquals("Strings are un equal", one, one_1);
		assertSame("Objects one & one 1 not equal", one, one_1);
		
		String one_new= new String("one");
		assertEquals("Strings are un equal", one, one_new);
		assertNotSame("Objects one & one_new  not equal", one, one_new);
		
	}
	@Test
	@Category({Regeression.class,Smoke.class})
	@Ignore
	public void B_ObjectEq()
	{
		AssertionsClass a= new AssertionsClass();
		AssertionsClass b= new AssertionsClass();
		 
		
		assertSame("Same object", b,a);
		assertEquals("Objects are un equal", b, a);
		
	}

}
