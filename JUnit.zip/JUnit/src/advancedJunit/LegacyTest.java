package advancedJunit;

import junit.framework.TestCase;

public class LegacyTest extends TestCase{
	
}
