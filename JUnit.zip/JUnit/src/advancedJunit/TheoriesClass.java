package advancedJunit;


import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.everyItem;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.startsWith;
import static org.junit.Assume.assumeThat;

import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

@RunWith(Theories.class)
public class TheoriesClass {
	@DataPoint
    public static String[] things= {"Nayeem","John"};
    @DataPoint
    public static Integer[] group= {5,2};

    @Theory
    public void Name(String[] thing,Integer[] gro) {
    	
    	 System.out.println(thing);
    
    }
	

}

