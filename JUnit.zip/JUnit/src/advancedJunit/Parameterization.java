package advancedJunit;



import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import junit.framework.TestCase;


@RunWith(Parameterized.class)
public class Parameterization {
	 private int numberA;
	    private int numberB;
	    private int expected;

	public Parameterization(int numberA, int numberB, int expected) {
        this.numberA = numberA;
        this.numberB = numberB;
        this.expected = expected;
    }

	// name attribute is optional, provide an unique name for test
	// multiple parameters, uses Collection<Object[]>
    @Parameters(name = "{index}: testAdd({0}+{1}) = {2}")
    public static Object[] data() {
        return new Object[][]{
                {1, 1, 2},
                {2, 2, 4},
                {8, 2, 10},
                {4, 5, 9},
                {5, 5, 10}
        };
    }

    
	@Test
    public void test_addTwoNumbes() {
        TestCase.assertEquals("NOn Matches",numberA+numberB, expected);
    }

}
