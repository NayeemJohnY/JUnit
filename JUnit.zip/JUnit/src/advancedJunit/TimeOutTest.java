package advancedJunit;

import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.MethodRule;
import org.junit.rules.TestRule;
import org.junit.rules.Timeout;
import org.junit.runners.MethodSorters;



@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TimeOutTest {
	@Rule
	public TestRule timeout= new Timeout(1200);
	
	
	
	@Test
	public void test1() throws Exception
	{
		Thread.sleep(1000);
	}

}
