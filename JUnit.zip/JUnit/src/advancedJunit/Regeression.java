package advancedJunit;

public class Regeression {

}
