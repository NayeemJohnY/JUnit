package advancedJunit;

public class User {
	
	String username;
	User(String username)
	{
		this.username=username;
	}

	public String configFileName() {
		// TODO Auto-generated method stub
		return username;
	}

}
