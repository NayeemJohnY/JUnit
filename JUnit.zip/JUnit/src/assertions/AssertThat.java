package assertions;

import org.junit.Test;
import static org.junit.Assert.assertThat;

import java.io.Serializable;

import static org.hamcrest.CoreMatchers.*;

public class AssertThat {
	
	@Test
	public  void IsAnything() {
		String tested="Nayeem";
		String check="John";
				
		assertThat("Matching failed", tested, anything(check));
		
	}
	@Test
	public  void IsNull() {
		String tested=null;
		assertThat("Matching failed", tested, nullValue());
		
	}
	@Test
	public  void IsNotNull() {
		String tested="John";
		
		assertThat("Matching failed", tested, notNullValue());
		
	}
	@Test
	public  void IsEqual() {
		String tested="John";
		String check="John";
		assertThat("Matching failed", tested, equalTo(check));
		assertThat("Matching failed", tested, is(check));
	}
	@Test
	public  void NotEqual() {
		String tested="John";
		String check="JAohn";

		assertThat("Matching failed", tested, anyOf(is(check),is("blue")));
	}
	@Test
	public  void Same() {
		String tested="John";
		String check=tested;

		assertThat("Matching failed", tested, sameInstance(check));
	}
	@Test
	public  void instance() {
		String tested="John";

		assertThat("Matching failed", tested, instanceOf(Serializable.class));
		assertThat("Matching failed", tested, isA(Serializable.class));
	}
	@Test
	public  void contains() {
		String tested="John";
		String check="hn";
		assertThat("Matching failed", tested, containsString(check));
	
	}
	@Test
	public  void starts() {
		String tested="John";
		String check="hn";
		assertThat("Matching failed", tested, startsWith(check));
	
	}
	@Test
	public  void ends() {
		String tested="John";
		String check="hn";
		assertThat("Matching failed", tested, is(sameInstance(check)));
	
	}
	@Test
	public  void negation() {
		String tested="John";
		String check="John";
		assertThat("Matching failed", tested, not(endsWith(check)));
	
	}
}
