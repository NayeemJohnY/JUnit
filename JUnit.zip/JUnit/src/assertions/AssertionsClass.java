package assertions;


import static org.junit.Assert.fail;

import org.junit.FixMethodOrder;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runners.MethodSorters;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AssertionsClass {
	
	@Test
	public void testTrue()
	{
		assertTrue("True is not false", true);
		System.out.println("True Test passed");
	}
	
	@Test
	public void testFalse()
	{
		assertFalse("False is not True", true);
		System.out.println("False Test passed");
	}
	
	@Test
	public void testFail()
	{
		fail("Test is failed");
		System.out.println("GOOD");
	}
	
	@Test
	public void testInteger()
	{
		long longvalue=-999999999;
		assertEquals("Long value ", longvalue, longvalue);
		
		int shortvalue=-999999999;
		short intvalue=10000;
		assertEquals("short & long value ", shortvalue, intvalue);
	}
	@Test
	public void testdouble()
	{
		double doubleval=45.99;
		float floatvalue=45.998f;
		assertEquals("double value 1", floatvalue, doubleval,.01);
		assertEquals("double value 2", floatvalue, doubleval,.001);
		assertEquals("double value 3", floatvalue, doubleval,.0001);
		
		
	}
	
}
