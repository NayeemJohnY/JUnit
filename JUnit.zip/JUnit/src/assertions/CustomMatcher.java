package assertions;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.hamcrest.Matcher;

public class CustomMatcher extends BaseMatcher<SampleClass> {
	 SampleClass expected;

	 
	 public static Matcher<SampleClass> excitedSample(SampleClass expected)
	 {
		return new CustomMatcher(expected);
		 
	 }
	@Override
	public  boolean matches(Object o) {
		// TODO Auto-generated method stub
		SampleClass s = (SampleClass) o;
		if (s.getNumber() > 10) {
			return s.getString().contains(expected.getString());
		}
		return true;
	}

	public CustomMatcher(SampleClass obj) {
		this.expected = obj;
	}

	@Override
	public void describeTo(Description d) {
		// TODO Auto-generated method stub
		d.appendText("Cutstom Matcher");
	}

}
