package assertions;


import static org.junit.Assert.*;

import org.junit.Test;

public class ArrayAssertions {
	
	@Test
	public void A()
	{
		int a[]= {1,2,3};
		int b[]=a;
		assertEquals("Arrays are un equal", a, b);
	}
	@Test
	public void B()
	{
		int a[]= {1,2,3};
		int b[]= {1,2,3};
		assertEquals("Arrays are un equal", a, b);
	}
	@Test
	public void C()
	{
		int a[]= {1,2,3};
		int b[]= {1,2,3};
		assertArrayEquals("Arrays are un equal", a, b);
	}
	@Test
	public void D()
	{
		int a[]= {1,2,3};
		int b[]= {1,2};
		assertArrayEquals("Arrays are un equal", a, b);
	}
	@Test
	public void E()
	{
		int a[]= {1,2,3};
		int b[]= {1,2,4};
		assertArrayEquals("Arrays are un equal", a, b);
	}
	@Test
	public void F()
	{
		Object[] a= {"Nayeem"};
		Object[] b= {new AssertionsClass()};
		
		assertArrayEquals("Arrays are un equal", a, b);
	}
	
	@Test(expected = AssertionError.class)
	public void G()
	{
		double[] a= {1.0,20.3,45.9};
		double[] b= {1.0,20.31,45.9};
		
		assertArrayEquals("Arrays are un equal", a, b,0.1);
		
		String[] astr= {"A","C"};
		String[] bstr= {"A","D"};;
		
		try
		{ 
			assertArrayEquals("Arrays are un equal", astr, bstr);
		}
		catch(Exception e)
		{
			System.out.println("ass");
		}
	}
}
