package assertions;


import static org.hamcrest.CoreMatchers.either;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;



import org.junit.Test;

public class CustomMatchersTest {
	
	@Test
	public  void customCheck() {
		
		
		SampleClass sam= new SampleClass(2,"Nayeem");
		SampleClass sss= new SampleClass(15,"Nayeem");
		assertThat("Custom Matcher",sss,CustomMatcher.excitedSample(sam));
		
	}
	@Test
	public  void customAdvanceCheck() {
		
		
		SampleClass sam= new SampleClass(2,"Nayeem");
		SampleClass sss= new SampleClass(15,"Nayeem");
		assertThat("Custom Matcher",sss,either(CustomMatcher.excitedSample(sam)).or(equalTo(sam)));
		
	}

}
