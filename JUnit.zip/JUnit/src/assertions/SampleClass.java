package assertions;

public class SampleClass {
	int num;
	String str;
	SampleClass(int num, String str)
	{
		this.num=num;
		this.str=str;
	}
	
	public  int getNumber()
	{
		return num;
		
	}
	
	public  String getString()
	{
		return str;
		
	}

}
