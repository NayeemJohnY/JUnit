package assertions;

import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.startsWith;
import static org.hamcrest.CoreMatchers.everyItem;
import static org.hamcrest.CoreMatchers.containsString;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;


import org.junit.Test;

public class CollectionsAssert {

	@Test
	public  void collectionContains() {
		
		Integer a[]= {1,5,6,7};
		Collection<Integer>list=Arrays.asList(a);
		assertThat("Not contains item",list,hasItem(1));
		
	}
	@Test
	public  void collectionCheck() {
		
		List<String>list=new ArrayList<String>();
		list.add("Nayeem");
		list.add("John");
		list.add("SDET");
		
		assertThat("Not contains item",list,hasItems("Nayeem","John","SDET","Good"));
		
	}
	@Test
	public  void collectionFind() {
		
		List<String>list=new ArrayList<String>();
		list.add("Nayeem");
		list.add("John");
		list.add("SDET");
		
		assertThat("Not contains item",list,hasItem(startsWith("C")));
		
	}
	@Test
	public  void collectionFilter() {
		
		List<String>list=new ArrayList<String>();
		list.add("Nayeem");
		list.add("Nayeem");
		list.add("SDET");
		
		assertThat("Not contains item",list,everyItem(not(containsString("SDET"))));
		
	}
}
