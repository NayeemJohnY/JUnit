package assertions;

import static org.junit.Assert.*;

import org.junit.Test;

public class ObjectEquality {
	
	@Test
	public void A_StringEq()
	{
		String one="one";
		String one_1="one";
		 
		assertEquals("Strings are un equal", one, one_1);
		assertSame("Objects one & one 1 not equal", one, one_1);
		
		String one_new= new String("one");
		assertEquals("Strings are un equal", one, one_new);
		assertNotSame("Objects one & one_new  not equal", one, one_new);
		
	}
	@Test
	public void B_ObjectEq()
	{
		AssertionsClass a= new AssertionsClass();
		AssertionsClass b= new AssertionsClass();
		 
		
		assertSame("Same object", b,a);
		assertEquals("Objects are un equal", b, a);
		
	}
	@Test
	public void C_NullObjectEq()
	{
		String str=null;
		String nullobj=null;
		assertSame("Same object", str,nullobj);
		assertEquals("Same Null", nullobj,str);
		assertNull("Not null vaLue", str);
		assertNotNull("Null value", str);
	}

}
