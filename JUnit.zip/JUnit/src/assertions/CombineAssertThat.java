package assertions;

import static org.junit.Assert.*;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.*;
public class CombineAssertThat {
	
	@Test
	public  void All() {
		String tested="Nayeem";
		
				
		assertThat("Matching failed", tested, allOf(startsWith("N"),endsWith("m"),containsString("e")));
		
	}
	@Test
	public  void any() {
		String tested="Nayeem";
		
				
		assertThat("Matching failed", tested, anyOf(startsWith("N"),endsWith("m"),containsString("e")));
		
	}
	@Test
	public  void combine() {
		String tested="Nayeem";
		
				
		assertThat("Matching failed", tested, not(anyOf(startsWith("J"),containsString("g"))));
		
	}
	@Test
	public  void regex() {
		String tested="Nayeem";
		
				
		assertTrue("Matching failed",tested.matches("[^0-9]*"));
		
	}
	@Test
	public  void Either() {
		String tested="Nayeem";
		
				
		assertThat("Matching failed",tested,either(startsWith("j"))
				
				.or(endsWith("g"))
				.and(containsString("h")));
		
	}
}
