package assertions;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertTrue;
import static org.junit.Assume.assumeNoException;
import static org.junit.Assume.assumeNotNull;
import static org.junit.Assume.assumeThat;
import static org.junit.Assume.assumeTrue;

import org.junit.Before;
import org.junit.Test;

public class AssumVsAssert {
	

	@Test
	public  void assumeCheck() {
		assumeTrue("True is not false", true);
		System.out.println("True is not false");
	
	}
	@Test
	public  void asertCheck() {
		assertTrue("True is not false", false);
		System.out.println("Assert Check");
	
	}
	@Test
	public  void assumeNull() {
		String str=null;
		assumeNotNull(str);
		System.out.println("Assume Null check");
	
	}
	@Test
	public  void assumeExcpetion() {
		try {
			Integer.parseInt("1A");
		}
		catch (NumberFormatException e) {
			assumeNoException("No number format excpetion", e);
		}
	}
	@Test
	public  void assumehat() {
		String str="Nayeem";
		assumeThat("That ",str, containsString("AA") );
		System.out.println("Assume That check");
	
	}
	@Test
	public  void badInput() {
		int data=0;
		assumeThat("That ",data, not(equalTo("4")));
		System.out.println("Assume bad input check");
		int answer=10/data;
	}
	
	@Before
	public void setup(){
		assumeTrue("Work in setup",false);
	}
}
