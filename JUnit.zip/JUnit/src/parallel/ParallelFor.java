package parallel;

import org.junit.Test;

public class ParallelFor {
	@Test
	public void forloop()
	{
		for(int i=0; i<100; i++)
		{
			System.out.println("For Loop "+i);
		}
	}

}
