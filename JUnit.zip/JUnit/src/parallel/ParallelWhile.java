package parallel;

import org.junit.Test;

public class ParallelWhile {
	@Test
	public void whileloop()
	{ int i=0;
		while(i++<100)
		{
			System.out.println("While Loop "+i);
		
		}
	}

}
