package junitpractise;

import org.junit.Test;


import junit.framework.TestCase;

public class TestTarget {
	
	@Test
	public void testAdd() {
		
		MyTarget myt= new MyTarget();
		TestCase.assertEquals("Answer is not equal",11, myt.add(5, 6));
		
		
	}
	@Test
	public void testAdd2() {
		
		MyTarget myt= new MyTarget();
		TestCase.assertEquals("Answer is not equal",10, myt.add(5, 6));
		
		
	}
	@Test
	public void ErrorTest() {
		
		throw new RuntimeException();
		
	}
	@Test(expected = ArithmeticException.class)
	public void ExceptionTest() {
		
		TestCase.assertEquals("Exception appears",10,100/10);
		
	}
}
