package junitpractise;

import static org.junit.Assert.*;

import org.junit.Test;



public class junitpractise {

	@Test(expected = ArithmeticException.class)
	public void test() {
		assertTrue(true);
		
	}
	@Test
	public void test2() {
		//assertTrue(false);
		assertEquals(5, 6);
		
	}

}
